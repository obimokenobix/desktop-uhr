﻿# Desktop-Uhr - zeigt Wochentag, Uhrzeit und Datum direkt auf dem Desktop.
# Start: Doppelklick auf "Desktop-Uhr starten.cmd" im selben Ordner.

$code = @'
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System;


namespace DesktopUhr
{
    public static class Program
    {
        [DllImport("user32.dll")] static extern bool SetProcessDPIAware();

        public static void Run(string scriptPath)
        {
            ClockForm.ScriptPath = scriptPath ?? "";
            bool created;
            using (Mutex mutex = new Mutex(true, "DesktopUhr_SingleInstance", out created))
            {
                if (!created)
                {
                    MessageBox.Show("Die Desktop-Uhr läuft bereits.\nRechtsklick auf die Uhr (oder das Symbol im Infobereich) öffnet die Einstellungen.",
                        "Desktop-Uhr", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                try { SetProcessDPIAware(); } catch { }
                Application.EnableVisualStyles();
                try { Application.SetCompatibleTextRenderingDefault(false); } catch { }
                Application.Run(new ClockForm(Settings.Load()));
            }
        }
    }
}


namespace DesktopUhr
{
    class Glyph
    {
        public string Key, Group, Text;
        public RectangleF Cell;
        public GraphicsPath Path;
        public bool Removed;
    }

    class Layout : IDisposable
    {
        public List<Glyph> Glyphs = new List<Glyph>();
        public float B, Pad;
        public void Dispose()
        {
            foreach (Glyph g in Glyphs) if (g.Path != null) g.Path.Dispose();
            Glyphs.Clear();
        }
    }

    static class Renderer
    {
        public static readonly float[] Sizes = { 56f, 84f, 120f, 170f };
        public static readonly string[] SizeNames = { "Klein", "Mittel", "Groß", "Sehr groß" };

        public static readonly Color[] Colors = {
            Color.FromArgb(255, 255, 255),
            Color.FromArgb(215, 220, 228),
            Color.FromArgb(150, 205, 255),
            Color.FromArgb(240, 200, 110),
            Color.FromArgb(255, 140, 120),
            Color.FromArgb(25, 25, 28)
        };
        public static readonly string[] ColorNames = { "Weiß", "Silber", "Eisblau", "Gold", "Koralle", "Schwarz" };

        static readonly string[] Days = { "Sonntag", "Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag" };
        static readonly string[] Months = { "Jänner", "Februar", "März", "April", "Mai", "Juni", "Juli", "August", "September", "Oktober", "November", "Dezember" };

        static readonly FontFamily TimeFamily;
        static readonly FontFamily TextFamily;
        static readonly StringFormat Fmt;
        static readonly Graphics MeasureG;

        static Renderer()
        {
            TimeFamily = Find("Segoe UI Light", "Segoe UI", "Arial", "DejaVu Sans");
            TextFamily = Find("Segoe UI Semilight", "Segoe UI", "Arial", "DejaVu Sans");
            Fmt = (StringFormat)StringFormat.GenericTypographic.Clone();
            Fmt.FormatFlags |= StringFormatFlags.MeasureTrailingSpaces;
            MeasureG = Graphics.FromImage(new Bitmap(1, 1));
            MeasureG.PageUnit = GraphicsUnit.Pixel;
            MeasureG.TextRenderingHint = TextRenderingHint.AntiAlias;
        }

        static FontFamily Find(params string[] names)
        {
            foreach (string n in names)
            {
                try { return new FontFamily(n); } catch { }
            }
            return FontFamily.GenericSansSerif;
        }

        public static string GroupName(string group)
        {
            switch (group)
            {
                case "wt": return "Wochentag";
                case "zeit": return "Uhrzeit";
                case "tag": return "Tag";
                case "mon": return "Monat";
                case "jahr": return "Jahr";
            }
            return group;
        }

        public static string TimeText(DateTime t, bool seconds)
        {
            return seconds
                ? string.Format("{0:00}:{1:00}:{2:00}", t.Hour, t.Minute, t.Second)
                : string.Format("{0:00}:{1:00}", t.Hour, t.Minute);
        }

        static string DateText(DateTime t, string month)
        {
            return t.Day + ". " + month.ToUpper() + " " + t.Year;
        }

        static float Adv(string ch, Font f)
        {
            return MeasureG.MeasureString(ch, f, int.MaxValue, Fmt).Width;
        }

        static float SpacedWidth(string text, FontFamily fam, float em, float spacing)
        {
            float w = 0;
            using (Font f = new Font(fam, em, FontStyle.Regular, GraphicsUnit.Pixel))
            {
                for (int i = 0; i < text.Length; i++)
                {
                    w += Adv(text[i].ToString(), f);
                    if (i < text.Length - 1) w += spacing;
                }
            }
            return w;
        }

        static RectangleF Ink(string text, FontFamily fam, float em)
        {
            using (GraphicsPath p = new GraphicsPath())
            {
                p.AddString(text, fam, (int)FontStyle.Regular, em, new PointF(0, 0), Fmt);
                return p.GetBounds();
            }
        }

        struct Seg
        {
            public string Ch, Key, Group;
            public Seg(string ch, string key, string group) { Ch = ch; Key = key; Group = group; }
        }

        static void AddLine(Layout L, Settings s, List<Seg> segs, FontFamily fam, float em, float spacing,
            float y, float inkTop, float lineH, int W)
        {
            float b = L.B;
            using (Font f = new Font(fam, em, FontStyle.Regular, GraphicsUnit.Pixel))
            {
                float[] adv = new float[segs.Count];
                float total = 0;
                for (int i = 0; i < segs.Count; i++)
                {
                    adv[i] = Adv(segs[i].Ch, f);
                    total += adv[i] + (i < segs.Count - 1 ? spacing : 0);
                }
                float x = AlignX(s.Align, W, L.Pad, total);
                for (int i = 0; i < segs.Count; i++)
                {
                    Seg sg = segs[i];
                    if (sg.Ch != " ")
                    {
                        PointF o = s.OffsetOf(sg.Key, sg.Group);
                        float gx = x + o.X * b, gy = y + o.Y * b;
                        GraphicsPath p = new GraphicsPath();
                        p.AddString(sg.Ch, fam, (int)FontStyle.Regular, em, new PointF(gx, gy - inkTop), Fmt);
                        Glyph g = new Glyph();
                        g.Key = sg.Key; g.Group = sg.Group; g.Text = sg.Ch; g.Path = p;
                        g.Cell = new RectangleF(gx, gy, Math.Max(adv[i], em * 0.25f), lineH);
                        g.Removed = s.IsRemoved(sg.Key, sg.Group);
                        L.Glyphs.Add(g);
                    }
                    x += adv[i] + spacing;
                }
            }
        }

        public static Layout Build(Settings s, DateTime now, float scale)
        {
            Layout L = new Layout();
            float b = Sizes[Clamp(s.Size, 0, Sizes.Length - 1)] * scale;
            float small = b * 0.25f;
            float spacing = small * 0.32f;
            L.B = b;
            L.Pad = Math.Max(6f, b * 0.12f);

            // Feste Breite, damit die Ausrichtung nicht springt
            float maxW = SpacedWidth(s.Seconds ? "00:00:00" : "00:00", TimeFamily, b, 0);
            if (s.Weekday)
                foreach (string d in Days) maxW = Math.Max(maxW, SpacedWidth(d.ToUpper(), TextFamily, small, spacing));
            foreach (string m in Months)
                maxW = Math.Max(maxW, SpacedWidth(DateText(new DateTime(2026, 1, 28), m), TextFamily, small, spacing));
            int W = (int)Math.Ceiling(maxW + 2 * L.Pad);

            RectangleF timeInk = Ink("00:00", TimeFamily, b);
            RectangleF capsTopInk = Ink("ÄH", TextFamily, small);
            RectangleF capsBaseInk = Ink("H", TextFamily, small);
            float capsH = capsBaseInk.Bottom - capsTopInk.Top;

            float y = L.Pad;
            if (s.Weekday)
            {
                string wd = Days[(int)now.DayOfWeek].ToUpper();
                List<Seg> segs = new List<Seg>();
                for (int i = 0; i < wd.Length; i++) segs.Add(new Seg(wd[i].ToString(), "wt." + i, "wt"));
                AddLine(L, s, segs, TextFamily, small, spacing, y, capsTopInk.Top, capsH, W);
                y += capsH + b * 0.17f;
            }
            {
                string t = TimeText(now, s.Seconds);
                List<Seg> segs = new List<Seg>();
                for (int i = 0; i < t.Length; i++) segs.Add(new Seg(t[i].ToString(), "zeit." + i, "zeit"));
                AddLine(L, s, segs, TimeFamily, b, 0, y, timeInk.Top, timeInk.Height, W);
                y += timeInk.Height + b * 0.16f;
            }
            {
                List<Seg> segs = new List<Seg>();
                string day = now.Day.ToString();
                for (int i = 0; i < day.Length; i++) segs.Add(new Seg(day[i].ToString(), "tag." + (day.Length - i), "tag"));
                segs.Add(new Seg(".", "tag.0", "tag"));
                segs.Add(new Seg(" ", "", ""));
                string mon = Months[now.Month - 1].ToUpper();
                for (int i = 0; i < mon.Length; i++) segs.Add(new Seg(mon[i].ToString(), "mon." + i, "mon"));
                segs.Add(new Seg(" ", "", ""));
                string yr = now.Year.ToString();
                for (int i = 0; i < yr.Length; i++) segs.Add(new Seg(yr[i].ToString(), "jahr." + i, "jahr"));
                AddLine(L, s, segs, TextFamily, small, spacing, y, capsTopInk.Top, capsH, W);
            }
            return L;
        }

        public static Bitmap Draw(Layout L, Settings s, bool edit, string hoverKey, string selKey, out Rectangle R)
        {
            RectangleF u = RectangleF.Empty;
            bool any = false;
            foreach (Glyph g in L.Glyphs)
            {
                if (g.Removed && !edit) continue;
                u = any ? RectangleF.Union(u, g.Cell) : g.Cell;
                any = true;
            }
            if (!any) u = new RectangleF(L.Pad, L.Pad, L.B * 0.4f, L.B * 0.4f);
            float pad = L.Pad;
            R = Rectangle.FromLTRB((int)Math.Floor(u.Left - pad), (int)Math.Floor(u.Top - pad),
                                   (int)Math.Ceiling(u.Right + pad), (int)Math.Ceiling(u.Bottom + pad));

            Color col = Colors[Clamp(s.Color, 0, Colors.Length - 1)];
            float op = Clamp(s.Opacity, 10, 100) / 100f;
            float b = L.B;

            Bitmap bmp = new Bitmap(Math.Max(1, R.Width), Math.Max(1, R.Height), PixelFormat.Format32bppArgb);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(Color.FromArgb(1, 0, 0, 0)); // fast unsichtbar, damit man die Uhr greifen kann
                g.TranslateTransform(-R.X, -R.Y);
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;
                g.CompositingQuality = CompositingQuality.HighQuality;

                if (edit)
                {
                    using (SolidBrush tint = new SolidBrush(Color.FromArgb(70, 0, 0, 0)))
                        g.FillRectangle(tint, R);
                    using (Pen frame = new Pen(Color.FromArgb(160, 255, 255, 255), 1f))
                    {
                        frame.DashStyle = DashStyle.Dash;
                        g.DrawRectangle(frame, R.X + 0.5f, R.Y + 0.5f, R.Width - 2, R.Height - 2);
                    }
                }

                using (GraphicsPath all = new GraphicsPath())
                {
                    foreach (Glyph gl in L.Glyphs) if (!gl.Removed) all.AddPath(gl.Path, false);

                    if (s.Shadow)
                    {
                        bool dark = col.GetBrightness() < 0.4f;
                        Color sc = dark ? Color.White : Color.Black;
                        float off = Math.Max(1f, b * 0.018f);
                        using (GraphicsPath sp = (GraphicsPath)all.Clone())
                        using (Matrix m = new Matrix())
                        {
                            m.Translate(off, off);
                            sp.Transform(m);
                            using (Pen soft = new Pen(Color.FromArgb((int)(40 * op), sc), Math.Max(2f, b * 0.045f)))
                            {
                                soft.LineJoin = LineJoin.Round;
                                g.DrawPath(soft, sp);
                            }
                            using (SolidBrush sb = new SolidBrush(Color.FromArgb((int)((dark ? 90 : 120) * op), sc)))
                                g.FillPath(sb, sp);
                        }
                    }
                    using (SolidBrush br = new SolidBrush(Color.FromArgb((int)(255 * op), col)))
                        g.FillPath(br, all);
                }

                if (edit)
                {
                    Color accent = Color.FromArgb(80, 170, 255);
                    using (SolidBrush ghost = new SolidBrush(Color.FromArgb(60, col)))
                    using (Pen ghostPen = new Pen(Color.FromArgb(90, 255, 255, 255), 1f))
                    {
                        ghostPen.DashStyle = DashStyle.Dot;
                        foreach (Glyph gl in L.Glyphs)
                        {
                            if (!gl.Removed) continue;
                            g.FillPath(ghost, gl.Path);
                            g.DrawRectangle(ghostPen, gl.Cell.X, gl.Cell.Y, gl.Cell.Width, gl.Cell.Height);
                        }
                    }
                    foreach (Glyph gl in L.Glyphs)
                    {
                        if (gl.Key == selKey)
                        {
                            using (SolidBrush sb = new SolidBrush(Color.FromArgb(60, accent)))
                                g.FillRectangle(sb, gl.Cell);
                            using (Pen p = new Pen(accent, 1.5f))
                                g.DrawRectangle(p, gl.Cell.X, gl.Cell.Y, gl.Cell.Width, gl.Cell.Height);
                        }
                        else if (gl.Key == hoverKey)
                        {
                            using (Pen p = new Pen(Color.FromArgb(200, accent), 1f))
                                g.DrawRectangle(p, gl.Cell.X, gl.Cell.Y, gl.Cell.Width, gl.Cell.Height);
                        }
                    }
                }
            }
            return bmp;
        }

        static float AlignX(int align, int W, float pad, float w)
        {
            if (align == 1) return (W - w) / 2f;
            if (align == 2) return W - pad - w;
            return pad;
        }

        public static int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }
    }
}


namespace DesktopUhr
{
    class Settings
    {
        public int X = int.MinValue, Y = int.MinValue;
        public int Size = 1;
        public int Color = 0;
        public int Align = 0;      // 0 links, 1 Mitte, 2 rechts
        public int Opacity = 100;
        public int Layer = 0;      // 0 Desktop, 1 Normal, 2 Immer im Vordergrund
        public bool Seconds = false, Weekday = true, Shadow = true, Locked = false;
        public bool FirstRun = true;

        // Versatz pro Zeichen ("mon.3") oder ganzer Teil ("mon.*"), in Vielfachen der Schriftgröße
        public Dictionary<string, PointF> Offsets = new Dictionary<string, PointF>();
        // Entfernte Zeichen ("mon.3") oder ganze Teile ("mon.*")
        public HashSet<string> Removed = new HashSet<string>();

        public PointF OffsetOf(string key, string group)
        {
            PointF a, b;
            Offsets.TryGetValue(key, out a);
            Offsets.TryGetValue(group + ".*", out b);
            return new PointF(a.X + b.X, a.Y + b.Y);
        }

        public bool IsRemoved(string key, string group)
        {
            return Removed.Contains(key) || Removed.Contains(group + ".*");
        }

        static string Dir
        {
            get { return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DesktopUhr"); }
        }
        static string FilePath { get { return Path.Combine(Dir, "einstellungen.ini"); } }

        public static Settings Load()
        {
            Settings s = new Settings();
            try
            {
                if (!File.Exists(FilePath)) return s;
                s.FirstRun = false;
                Dictionary<string, string> d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                foreach (string line in File.ReadAllLines(FilePath))
                {
                    int i = line.IndexOf('=');
                    if (i > 0) d[line.Substring(0, i).Trim()] = line.Substring(i + 1).Trim();
                }
                s.X = Int(d, "X", s.X); s.Y = Int(d, "Y", s.Y);
                s.Size = Int(d, "Groesse", s.Size); s.Color = Int(d, "Farbe", s.Color);
                s.Align = Int(d, "Ausrichtung", s.Align); s.Opacity = Int(d, "Deckkraft", s.Opacity);
                s.Layer = Int(d, "Ebene", s.Layer);
                s.Seconds = Bool(d, "Sekunden", s.Seconds); s.Weekday = Bool(d, "Wochentag", s.Weekday);
                s.Shadow = Bool(d, "Schatten", s.Shadow); s.Locked = Bool(d, "Gesperrt", s.Locked);

                string v;
                if (d.TryGetValue("Versatz", out v))
                {
                    foreach (string part in v.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries))
                    {
                        string[] p = part.Split(':');
                        float x, y;
                        if (p.Length == 3 && float.TryParse(p[1], NumberStyles.Float, CultureInfo.InvariantCulture, out x)
                                          && float.TryParse(p[2], NumberStyles.Float, CultureInfo.InvariantCulture, out y))
                            s.Offsets[p[0]] = new PointF(x, y);
                    }
                }
                if (d.TryGetValue("Entfernt", out v))
                    foreach (string k in v.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                        s.Removed.Add(k.Trim());
            }
            catch { }
            return s;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Dir);
                StringBuilder off = new StringBuilder();
                foreach (KeyValuePair<string, PointF> kv in Offsets)
                {
                    if (kv.Value.X == 0 && kv.Value.Y == 0) continue;
                    if (off.Length > 0) off.Append('|');
                    off.Append(kv.Key).Append(':')
                       .Append(kv.Value.X.ToString("R", CultureInfo.InvariantCulture)).Append(':')
                       .Append(kv.Value.Y.ToString("R", CultureInfo.InvariantCulture));
                }
                File.WriteAllLines(FilePath, new string[] {
                    "X=" + X, "Y=" + Y, "Groesse=" + Size, "Farbe=" + Color, "Ausrichtung=" + Align,
                    "Deckkraft=" + Opacity, "Ebene=" + Layer, "Sekunden=" + Seconds, "Wochentag=" + Weekday,
                    "Schatten=" + Shadow, "Gesperrt=" + Locked,
                    "Versatz=" + off, "Entfernt=" + string.Join(",", new List<string>(Removed).ToArray())
                });
                FirstRun = false;
            }
            catch { }
        }

        static int Int(Dictionary<string, string> d, string k, int def)
        {
            string v; int r;
            return d.TryGetValue(k, out v) && int.TryParse(v, out r) ? r : def;
        }
        static bool Bool(Dictionary<string, string> d, string k, bool def)
        {
            string v; bool r;
            return d.TryGetValue(k, out v) && bool.TryParse(v, out r) ? r : def;
        }
    }
}


namespace DesktopUhr
{
    public class ClockForm : Form
    {
        readonly Settings s;
        readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
        readonly ContextMenuStrip menu = new ContextMenuStrip();
        readonly ContextMenuStrip glyphMenu = new ContextMenuStrip();
        readonly NotifyIcon tray = new NotifyIcon();
        string lastKey = "";
        float scale = 1f;
        bool ready;

        Layout layout;
        Rectangle R;               // aktuelle Zeichenfläche in Layout-Koordinaten

        // Bearbeiten-Modus
        bool edit;
        string hoverKey, selKey;
        bool dragging, dragPushed;
        Point dragStart;
        string dragKey;
        PointF dragStartOff;

        struct Snapshot { public Dictionary<string, PointF> Off; public HashSet<string> Rem; }
        readonly Stack<Snapshot> undo = new Stack<Snapshot>();

        public static string ScriptPath = "";
        static string StartupFile
        {
            get { return System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Startup), "Desktop-Uhr.cmd"); }
        }

        internal ClockForm(Settings settings)
        {
            s = settings;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            KeyPreview = true;
            Text = "Desktop-Uhr";
            try { using (Graphics g = Graphics.FromHwnd(IntPtr.Zero)) scale = g.DpiX / 96f; } catch { }

            try { Icon = MakeIcon(); } catch { Icon = SystemIcons.Application; }
            tray.Icon = Icon;
            tray.Text = "Desktop-Uhr";
            tray.ContextMenuStrip = menu;
            tray.Visible = true;

            menu.Opening += delegate { BuildMenu(); };
            BuildMenu();

            if (s.FirstRun) s.Save();
            if (IsAutostart()) SetAutostart(true); // Pfad aktualisieren, falls der Ordner verschoben wurde

            timer.Interval = 200;
            timer.Tick += delegate { Redraw(false); };
            Microsoft.Win32.SystemEvents.DisplaySettingsChanged += delegate { EnsureOnScreen(); Redraw(true); };
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00080000 /*WS_EX_LAYERED*/ | 0x00000080 /*WS_EX_TOOLWINDOW*/;
                return cp;
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            Rectangle r = MeasureR();
            if (s.X == int.MinValue || !OnSomeScreen(new Rectangle(s.X + r.X, s.Y + r.Y, r.Width, r.Height)))
                SetDefaultAnchor(r);
            Bounds = new Rectangle(s.X + r.X, s.Y + r.Y, r.Width, r.Height);
            ApplyLayer();
            ready = true;
            Redraw(true);
            timer.Start();
        }

        // ---------- Zeichnen ----------

        Rectangle MeasureR()
        {
            Rectangle r;
            using (Layout L = Renderer.Build(s, DateTime.Now, scale))
            using (Renderer.Draw(L, s, edit, null, null, out r)) { }
            return r;
        }

        void Redraw(bool force)
        {
            if (!ready) return;
            DateTime now = DateTime.Now;
            string key = Renderer.TimeText(now, s.Seconds) + now.Date.Ticks;
            if (!force && key == lastKey) return;
            lastKey = key;

            if (layout != null) layout.Dispose();
            layout = Renderer.Build(s, now, scale);
            Rectangle r;
            using (Bitmap bmp = Renderer.Draw(layout, s, edit, hoverKey, selKey, out r))
            {
                R = r;
                SetBitmap(bmp, new Point(s.X + r.X, s.Y + r.Y));
            }
        }

        void SetBitmap(Bitmap bmp, Point pos)
        {
            IntPtr screenDc = GetDC(IntPtr.Zero);
            IntPtr memDc = CreateCompatibleDC(screenDc);
            IntPtr hBmp = IntPtr.Zero, old = IntPtr.Zero;
            try
            {
                hBmp = bmp.GetHbitmap(Color.FromArgb(0));
                old = SelectObject(memDc, hBmp);
                SIZE size = new SIZE { cx = bmp.Width, cy = bmp.Height };
                POINT src = new POINT { x = 0, y = 0 };
                POINT dst = new POINT { x = pos.X, y = pos.Y };
                BLENDFUNCTION blend = new BLENDFUNCTION { BlendOp = 0, BlendFlags = 0, SourceConstantAlpha = 255, AlphaFormat = 1 };
                UpdateLayeredWindow(Handle, screenDc, ref dst, ref size, memDc, ref src, 0, ref blend, 2 /*ULW_ALPHA*/);
            }
            finally
            {
                ReleaseDC(IntPtr.Zero, screenDc);
                if (hBmp != IntPtr.Zero) { SelectObject(memDc, old); DeleteObject(hBmp); }
                DeleteDC(memDc);
            }
        }

        // ---------- Position ----------

        void SetDefaultAnchor(Rectangle r)
        {
            Rectangle wa = Screen.PrimaryScreen.WorkingArea;
            int m = (int)(40 * scale);
            s.X = wa.Right - m - r.Right;
            s.Y = wa.Top + m - r.Y;
        }

        static bool OnSomeScreen(Rectangle r)
        {
            Point c = new Point(r.Left + r.Width / 2, r.Top + Math.Min(r.Height / 2, 40));
            foreach (Screen sc in Screen.AllScreens)
                if (sc.Bounds.Contains(c)) return true;
            return false;
        }

        void EnsureOnScreen()
        {
            if (!OnSomeScreen(Bounds)) { SetDefaultAnchor(R); s.Save(); }
        }

        void SaveAnchorFromWindow()
        {
            s.X = Left - R.X;
            s.Y = Top - R.Y;
            s.Save();
        }

        void StartWindowDrag()
        {
            ReleaseCapture();
            SendMessage(Handle, 0xA1 /*WM_NCLBUTTONDOWN*/, (IntPtr)2 /*HTCAPTION*/, IntPtr.Zero);
        }

        // ---------- Maus ----------

        Glyph HitTest(Point client)
        {
            if (layout == null) return null;
            PointF p = new PointF(client.X + R.X, client.Y + R.Y);
            for (int i = layout.Glyphs.Count - 1; i >= 0; i--)
            {
                Glyph g = layout.Glyphs[i];
                if (g.Removed && !edit) continue;
                if (g.Cell.Contains(p)) return g;
            }
            return null;
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Button != MouseButtons.Left) return;
            if (!edit)
            {
                if (!s.Locked) StartWindowDrag();
                return;
            }
            Activate();
            Glyph g = HitTest(e.Location);
            if (g == null)
            {
                selKey = null;
                Redraw(true);
                StartWindowDrag();
                return;
            }
            selKey = g.Key;
            bool whole = (ModifierKeys & Keys.Control) != 0;
            dragKey = whole ? g.Group + ".*" : g.Key;
            PointF o;
            s.Offsets.TryGetValue(dragKey, out o);
            dragStartOff = o;
            dragStart = Cursor.Position;
            dragging = true;
            dragPushed = false;
            Capture = true;
            Redraw(true);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (!edit) return;
            if (dragging && layout != null)
            {
                Point c = Cursor.Position;
                int dx = c.X - dragStart.X, dy = c.Y - dragStart.Y;
                if (!dragPushed && (dx != 0 || dy != 0)) { PushUndo(); dragPushed = true; }
                if (dragPushed)
                {
                    s.Offsets[dragKey] = new PointF(dragStartOff.X + dx / layout.B, dragStartOff.Y + dy / layout.B);
                    Redraw(true);
                }
                return;
            }
            Glyph g = HitTest(e.Location);
            string k = g == null ? null : g.Key;
            Cursor = g == null ? Cursors.Default : Cursors.SizeAll;
            if (k != hoverKey) { hoverKey = k; Redraw(true); }
        }

        protected override void OnMouseUp(MouseEventArgs e)
        {
            base.OnMouseUp(e);
            if (e.Button == MouseButtons.Left && dragging)
            {
                dragging = false;
                Capture = false;
                if (dragPushed) s.Save();
                return;
            }
            if (e.Button == MouseButtons.Right)
            {
                Glyph g = edit ? HitTest(e.Location) : null;
                if (g != null)
                {
                    selKey = g.Key;
                    Redraw(true);
                    BuildGlyphMenu(g);
                    glyphMenu.Show(Cursor.Position);
                }
                else
                {
                    BuildMenu();
                    menu.Show(Cursor.Position);
                }
            }
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (edit && hoverKey != null && !dragging) { hoverKey = null; Redraw(true); }
        }

        // ---------- Tastatur (im Bearbeiten-Modus) ----------

        protected override bool IsInputKey(Keys keyData)
        {
            Keys k = keyData & Keys.KeyCode;
            if (k == Keys.Left || k == Keys.Right || k == Keys.Up || k == Keys.Down) return true;
            return base.IsInputKey(keyData);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (!edit) return;
            if (e.KeyCode == Keys.Escape) { SetEdit(false); return; }
            if (e.Control && e.KeyCode == Keys.Z) { Undo(); return; }
            Glyph g = FindGlyph(selKey);
            if (g == null) return;
            if (e.KeyCode == Keys.Delete || e.KeyCode == Keys.Back)
            {
                if (e.Control) SetGroupRemoved(g, true); else SetGlyphRemoved(g, !g.Removed);
                return;
            }
            int step = e.Shift ? 10 : 1;
            int dx = 0, dy = 0;
            if (e.KeyCode == Keys.Left) dx = -step;
            else if (e.KeyCode == Keys.Right) dx = step;
            else if (e.KeyCode == Keys.Up) dy = -step;
            else if (e.KeyCode == Keys.Down) dy = step;
            if (dx == 0 && dy == 0) return;
            PushUndo();
            string key = e.Control ? g.Group + ".*" : g.Key;
            PointF o;
            s.Offsets.TryGetValue(key, out o);
            s.Offsets[key] = new PointF(o.X + dx / layout.B, o.Y + dy / layout.B);
            s.Save();
            Redraw(true);
            e.Handled = true;
        }

        Glyph FindGlyph(string key)
        {
            if (key == null || layout == null) return null;
            foreach (Glyph g in layout.Glyphs) if (g.Key == key) return g;
            return null;
        }

        // ---------- Bearbeiten: Aktionen ----------

        void SetEdit(bool on)
        {
            if (edit == on) return;
            edit = on;
            hoverKey = null; selKey = null; dragging = false;
            Cursor = Cursors.Default;
            ApplyLayer();
            if (on)
            {
                Activate();
                tray.ShowBalloonTip(8000, "Bearbeiten-Modus",
                    "Zeichen ziehen = verschieben, Strg+ziehen = ganzen Teil verschieben.\n" +
                    "Entf = Zeichen entfernen, Rechtsklick = mehr. Esc = fertig.", ToolTipIcon.Info);
            }
            else
            {
                s.Save();
            }
            Redraw(true);
        }

        void PushUndo()
        {
            Snapshot sn;
            sn.Off = new Dictionary<string, PointF>(s.Offsets);
            sn.Rem = new HashSet<string>(s.Removed);
            undo.Push(sn);
            if (undo.Count > 200)
            {
                Snapshot[] arr = undo.ToArray();
                undo.Clear();
                for (int i = 99; i >= 0; i--) undo.Push(arr[i]);
            }
        }

        void Undo()
        {
            if (undo.Count == 0) return;
            Snapshot sn = undo.Pop();
            s.Offsets = sn.Off;
            s.Removed = sn.Rem;
            s.Save();
            Redraw(true);
        }

        void SetGlyphRemoved(Glyph g, bool remove)
        {
            PushUndo();
            if (remove)
            {
                s.Removed.Add(g.Key);
            }
            else
            {
                s.Removed.Remove(g.Key);
                if (s.Removed.Remove(g.Group + ".*"))
                {
                    // Ganzer Teil war entfernt: alle anderen Zeichen davon bleiben entfernt
                    foreach (Glyph o in layout.Glyphs)
                        if (o.Group == g.Group && o.Key != g.Key) s.Removed.Add(o.Key);
                }
            }
            s.Save();
            Redraw(true);
        }

        void SetGroupRemoved(Glyph g, bool remove)
        {
            PushUndo();
            string prefix = g.Group + ".";
            s.Removed.RemoveWhere(delegate (string k) { return k.StartsWith(prefix); });
            if (remove) s.Removed.Add(g.Group + ".*");
            s.Save();
            Redraw(true);
        }

        void ResetGlyphPos(Glyph g, bool wholeGroup)
        {
            PushUndo();
            if (wholeGroup)
            {
                string prefix = g.Group + ".";
                List<string> keys = new List<string>(s.Offsets.Keys);
                foreach (string k in keys) if (k.StartsWith(prefix)) s.Offsets.Remove(k);
            }
            else s.Offsets.Remove(g.Key);
            s.Save();
            Redraw(true);
        }

        void ResetLayout()
        {
            PushUndo();
            s.Offsets.Clear();
            s.Removed.Clear();
            s.Save();
            Redraw(true);
        }

        void RestoreAll()
        {
            PushUndo();
            s.Removed.Clear();
            s.Save();
            Redraw(true);
        }

        // ---------- Ebene (Desktop / Normal / Vordergrund) ----------

        void ApplyLayer()
        {
            if (edit)
            {
                SetOwner(IntPtr.Zero);
                TopMost = true;
                return;
            }
            IntPtr owner = IntPtr.Zero;
            if (s.Layer == 0) owner = FindWindow("Progman", null);
            SetOwner(owner);
            TopMost = s.Layer == 2;
            if (s.Layer == 0)
                SetWindowPos(Handle, (IntPtr)1 /*HWND_BOTTOM*/, 0, 0, 0, 0, 0x0013 /*NOSIZE|NOMOVE|NOACTIVATE*/);
        }

        void SetOwner(IntPtr owner)
        {
            if (IntPtr.Size == 8) SetWindowLongPtr64(Handle, -8 /*GWL_HWNDPARENT*/, owner);
            else SetWindowLong32(Handle, -8, owner.ToInt32());
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == 0x0046 /*WM_WINDOWPOSCHANGING*/ && ready && s.Layer == 0 && !edit)
            {
                WINDOWPOS wp = (WINDOWPOS)Marshal.PtrToStructure(m.LParam, typeof(WINDOWPOS));
                wp.hwndInsertAfter = (IntPtr)1; // HWND_BOTTOM: bleibt immer hinter den Fenstern
                wp.flags &= ~0x0004u;            // SWP_NOZORDER entfernen
                Marshal.StructureToPtr(wp, m.LParam, false);
            }
            else if (m.Msg == 0x0232 /*WM_EXITSIZEMOVE*/)
            {
                SaveAnchorFromWindow();
            }
            base.WndProc(ref m);
        }

        // ---------- Menüs ----------

        void BuildGlyphMenu(Glyph g)
        {
            glyphMenu.Items.Clear();
            string part = Renderer.GroupName(g.Group);
            glyphMenu.Items.Add(new ToolStripMenuItem("Zeichen „" + g.Text + "“ (" + part + ")") { Enabled = false });
            glyphMenu.Items.Add(new ToolStripSeparator());
            if (g.Removed)
                glyphMenu.Items.Add(Item("Dieses Zeichen wiederherstellen", false, delegate { SetGlyphRemoved(g, false); }));
            else
                glyphMenu.Items.Add(Item("Dieses Zeichen entfernen\tEntf", false, delegate { SetGlyphRemoved(g, true); }));

            bool groupGone = s.Removed.Contains(g.Group + ".*");
            if (groupGone)
                glyphMenu.Items.Add(Item("Ganzen Teil wiederherstellen (" + part + ")", false, delegate { SetGroupRemoved(g, false); }));
            else
                glyphMenu.Items.Add(Item("Ganzen Teil entfernen (" + part + ")\tStrg+Entf", false, delegate { SetGroupRemoved(g, true); }));

            glyphMenu.Items.Add(new ToolStripSeparator());
            glyphMenu.Items.Add(Item("Position dieses Zeichens zurücksetzen", false, delegate { ResetGlyphPos(g, false); }));
            glyphMenu.Items.Add(Item("Position des ganzen Teils zurücksetzen", false, delegate { ResetGlyphPos(g, true); }));
            glyphMenu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem u = Item("Rückgängig\tStrg+Z", false, delegate { Undo(); });
            u.Enabled = undo.Count > 0;
            glyphMenu.Items.Add(u);
            glyphMenu.Items.Add(Item("Bearbeiten beenden\tEsc", false, delegate { SetEdit(false); }));
        }

        void BuildMenu()
        {
            menu.Items.Clear();
            menu.Items.Add(new ToolStripMenuItem("Desktop-Uhr") { Enabled = false });
            menu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem ed = Item("Bearbeiten-Modus (Zeichen verschieben/entfernen)", edit, delegate { SetEdit(!edit); });
            ed.Font = new Font(ed.Font, FontStyle.Bold);
            menu.Items.Add(ed);
            if (edit)
            {
                ToolStripMenuItem u = Item("Rückgängig\tStrg+Z", false, delegate { Undo(); });
                u.Enabled = undo.Count > 0;
                menu.Items.Add(u);
            }
            ToolStripMenuItem rest = Item("Entfernte Zeichen wiederherstellen", false, delegate { RestoreAll(); });
            rest.Enabled = s.Removed.Count > 0;
            menu.Items.Add(rest);
            ToolStripMenuItem rl = Item("Layout zurücksetzen (alles wie am Anfang)", false, delegate { ResetLayout(); });
            rl.Enabled = s.Removed.Count > 0 || s.Offsets.Count > 0;
            menu.Items.Add(rl);
            menu.Items.Add(new ToolStripSeparator());

            ToolStripMenuItem size = new ToolStripMenuItem("Größe");
            for (int i = 0; i < Renderer.SizeNames.Length; i++)
            {
                int k = i;
                size.DropDownItems.Add(Item(Renderer.SizeNames[i], s.Size == i, delegate { s.Size = k; Changed(); }));
            }
            menu.Items.Add(size);

            ToolStripMenuItem color = new ToolStripMenuItem("Farbe");
            for (int i = 0; i < Renderer.ColorNames.Length; i++)
            {
                int k = i;
                ToolStripMenuItem it = Item(Renderer.ColorNames[i], s.Color == i, delegate { s.Color = k; Changed(); });
                it.Image = Swatch(Renderer.Colors[i]);
                color.DropDownItems.Add(it);
            }
            menu.Items.Add(color);

            ToolStripMenuItem op = new ToolStripMenuItem("Deckkraft");
            foreach (int v in new int[] { 100, 80, 60, 40 })
            {
                int k = v;
                op.DropDownItems.Add(Item(v + " %", s.Opacity == v, delegate { s.Opacity = k; Changed(); }));
            }
            menu.Items.Add(op);

            ToolStripMenuItem align = new ToolStripMenuItem("Ausrichtung");
            string[] an = { "Links", "Mitte", "Rechts" };
            for (int i = 0; i < an.Length; i++)
            {
                int k = i;
                align.DropDownItems.Add(Item(an[i], s.Align == i, delegate { s.Align = k; Changed(); }));
            }
            menu.Items.Add(align);

            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(Item("Sekunden anzeigen", s.Seconds, delegate { s.Seconds = !s.Seconds; Changed(); }));
            menu.Items.Add(Item("Wochentag anzeigen", s.Weekday, delegate { s.Weekday = !s.Weekday; Changed(); }));
            menu.Items.Add(Item("Schatten", s.Shadow, delegate { s.Shadow = !s.Shadow; Changed(); }));

            menu.Items.Add(new ToolStripSeparator());
            ToolStripMenuItem layer = new ToolStripMenuItem("Ebene");
            string[] ln = { "Auf dem Desktop (hinter Fenstern)", "Normal", "Immer im Vordergrund" };
            for (int i = 0; i < ln.Length; i++)
            {
                int k = i;
                layer.DropDownItems.Add(Item(ln[i], s.Layer == i, delegate { s.Layer = k; s.Save(); ApplyLayer(); }));
            }
            menu.Items.Add(layer);
            menu.Items.Add(Item("Position sperren", s.Locked, delegate { s.Locked = !s.Locked; s.Save(); }));
            menu.Items.Add(Item("Position zurücksetzen", false, delegate { SetDefaultAnchor(R); s.Save(); Redraw(true); }));
            menu.Items.Add(Item("Mit Windows starten", IsAutostart(), delegate { SetAutostart(!IsAutostart()); }));

            menu.Items.Add(new ToolStripSeparator());
            menu.Items.Add(Item("Beenden", false, delegate { Close(); }));
        }

        static ToolStripMenuItem Item(string text, bool check, EventHandler click)
        {
            string shortcut = null;
            int tab = text.IndexOf('\t');
            if (tab >= 0) { shortcut = text.Substring(tab + 1); text = text.Substring(0, tab); }
            ToolStripMenuItem it = new ToolStripMenuItem(text);
            if (shortcut != null) it.ShortcutKeyDisplayString = shortcut;
            it.Checked = check;
            it.Click += click;
            return it;
        }

        static Image Swatch(Color c)
        {
            Bitmap b = new Bitmap(14, 14);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.Clear(Color.Transparent);
                using (SolidBrush br = new SolidBrush(c)) g.FillRectangle(br, 1, 1, 12, 12);
                g.DrawRectangle(Pens.Gray, 1, 1, 11, 11);
            }
            return b;
        }

        void Changed()
        {
            s.Save();
            Redraw(true);
        }

        // ---------- Autostart ----------

        static bool IsAutostart()
        {
            try { return System.IO.File.Exists(StartupFile); } catch { return false; }
        }

        static void SetAutostart(bool on)
        {
            try
            {
                if (on && ScriptPath.Length > 0)
                {
                    System.IO.File.WriteAllText(StartupFile,
                        "@echo off\r\nchcp 65001 >nul\r\nstart \"\" /min powershell.exe -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File \"" + ScriptPath + "\"\r\n",
                        new System.Text.UTF8Encoding(false));
                }
                else if (!on && System.IO.File.Exists(StartupFile))
                {
                    System.IO.File.Delete(StartupFile);
                }
            }
            catch { }
        }

        static Icon MakeIcon()
        {
            Bitmap b = new Bitmap(32, 32);
            using (Graphics g = Graphics.FromImage(b))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                g.Clear(Color.Transparent);
                using (SolidBrush rim = new SolidBrush(Color.FromArgb(30, 36, 48))) g.FillEllipse(rim, 1, 1, 30, 30);
                using (SolidBrush face = new SolidBrush(Color.FromArgb(245, 247, 250))) g.FillEllipse(face, 4, 4, 24, 24);
                using (Pen h = new Pen(Color.FromArgb(30, 36, 48), 2.6f)) { g.DrawLine(h, 16, 16, 11, 11); g.DrawLine(h, 16, 16, 22, 9); }
                using (SolidBrush dot = new SolidBrush(Color.FromArgb(220, 70, 60))) g.FillEllipse(dot, 14, 14, 4, 4);
            }
            return Icon.FromHandle(b.GetHicon());
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            timer.Stop();
            tray.Visible = false;
            tray.Dispose();
            base.OnFormClosed(e);
        }

        // ---------- Win32 ----------

        [StructLayout(LayoutKind.Sequential)] struct POINT { public int x, y; }
        [StructLayout(LayoutKind.Sequential)] struct SIZE { public int cx, cy; }
        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        struct BLENDFUNCTION { public byte BlendOp, BlendFlags, SourceConstantAlpha, AlphaFormat; }
        [StructLayout(LayoutKind.Sequential)]
        struct WINDOWPOS { public IntPtr hwnd, hwndInsertAfter; public int x, y, cx, cy; public uint flags; }

        [DllImport("user32.dll", SetLastError = true)]
        static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr hdcDst, ref POINT pptDst, ref SIZE psize,
            IntPtr hdcSrc, ref POINT pptSrc, int crKey, ref BLENDFUNCTION pblend, int dwFlags);
        [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll")] static extern IntPtr CreateCompatibleDC(IntPtr hDC);
        [DllImport("gdi32.dll")] static extern bool DeleteDC(IntPtr hdc);
        [DllImport("gdi32.dll")] static extern IntPtr SelectObject(IntPtr hDC, IntPtr hObject);
        [DllImport("gdi32.dll")] static extern bool DeleteObject(IntPtr hObject);
        [DllImport("user32.dll")] static extern bool ReleaseCapture();
        [DllImport("user32.dll")] static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wp, IntPtr lp);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] static extern IntPtr FindWindow(string cls, string name);
        [DllImport("user32.dll")]
        static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
        static extern IntPtr SetWindowLongPtr64(IntPtr hWnd, int idx, IntPtr val);
        [DllImport("user32.dll", EntryPoint = "SetWindowLongW")]
        static extern int SetWindowLong32(IntPtr hWnd, int idx, int val);
    }
}
'@

try {
    Add-Type -TypeDefinition $code -ReferencedAssemblies System.Windows.Forms, System.Drawing -ErrorAction Stop
    [DesktopUhr.Program]::Run($PSCommandPath)
}
catch {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("Die Desktop-Uhr konnte nicht starten:`n`n" + $_.Exception.Message, "Desktop-Uhr") | Out-Null
}
